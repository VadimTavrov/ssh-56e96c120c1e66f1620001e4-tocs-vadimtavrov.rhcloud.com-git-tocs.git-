@extends('layout')

@section('content')
        <div class="title-page"><span>История игр</span></div>

        <div class="content">
            <!-- <middle> -->

            <div class="added" style="padding-top: 30px;">

                @forelse($games as $game)
                <div class="short">
                    <div class="top">
                        <div class="left">
                            <img src="{{ $game->winner->avatar }}" alt="" title="" />
                            <div class="user"><span>{{ $game->winner->username }}</span></div>
                            <div class="numbs">
                                <div>Выигрыш: {{ $game->price }} руб.</div>
                                <div>Шанс: {{ \App\Http\Controllers\GameController::_getUserChanceOfGame($game->winner, $game) }}%</div>
                            </div>
                        </div>
                        <div class="right">ИГРА #{{ $game->id }}</div>
                    </div>
                    <div class="items">
                        @foreach(json_decode($game->won_items) as $item)
                        <div class="block">
                            @if(!isset($item->img))
                                <img src="https://steamcommunity-a.akamaihd.net/economy/image/class/{{ \App\Http\Controllers\GameController::APPID }}/{{ $item->classid }}/52fx53f" alt=""/>
                            @else
                                <img src="{{ asset($item->img) }}" alt="" class="south" original-title="{{ $item->name }}" />
                            @endif
                            <div class="price">{{ $item->price }} руб.</div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @empty
                    <div class="deposit-txt-info">
                        Пока что не было ни одной игры
                    </div>
                @endforelse


            </div>

            <!-- </middle> -->
        </div>
@endsection