<?php

namespace App\Http\Controllers;

use App\Bet;
use App\Game;
use App\Item;
use App\Services\SteamItem;
use App\User;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class PagesController extends Controller
{

    public function support()
    {
        parent::setTitle('Поддержка | ');

        return view('pages.support');
    }

    public function about()
    {
        parent::setTitle('О сайте | ');

        return view('pages.about');
    }

    public function top()
    {
        parent::setTitle('Топ | ');

        $users = \DB::table('users')
            ->select('users.id',
                'users.username',
                'users.avatar',
                'users.steamid64',
                \DB::raw('SUM(games.price) as top_value'),
                \DB::raw('COUNT(games.id) as wins_count')
            )
            ->join('games', 'games.winner_id', '=', 'users.id')
            ->groupBy('users.id')
            ->orderBy('top_value', 'desc')
            ->limit(20)
            ->get();
        $place = 1;
        $i = 0;
        foreach ($users as $u) {
            $users[$i]->games_played = count(\DB::table('games')
                ->join('bets', 'games.id', '=', 'bets.game_id')
                ->where('bets.user_id', $u->id)
                ->groupBy('bets.game_id')
                ->select('bets.id')->get());
            $users[$i]->win_rate = round($users[$i]->wins_count / $users[$i]->games_played, 3) * 100;
            $i++;
        }
        return view('pages.top', compact('users', 'place'));
    }


    public function history()
    {
        parent::setTitle('История игр | ');

        $games = Game::with(['bets', 'winner'])->where('status', Game::STATUS_FINISHED)->orderBy('created_at', 'desc')->simplePaginate(10);
        return view('pages.history', compact('games'));
    }


    public static function sortByChance($chances)
    {
        usort($chances, function ($a, $b) {
            $a1 = $a->chance;
            $b1 = $b->chance;
            return $a1 < $b1;
        });

        return $chances;
    }

    public function pay(Request $request)
    {
        $amount = $request->get('sum');
        $user = $this->user;
        header('Location: https://api.gdonate.ru/pay?public_key='.\App\Http\Controllers\GameController::GDonateKeyPublic.'&sum='.$amount.'&account='.$user->id.'&desc=Пополнение баланса на FASTVICTORY.RU');
        exit();
    }
    
}
