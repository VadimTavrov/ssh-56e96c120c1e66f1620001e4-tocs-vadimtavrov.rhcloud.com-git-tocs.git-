/*
Config file
*/

var config = {
    serverPort: 2020,
    bot: {
        steamid: 'Слил ru-skript.ru',
        username: '',
        password: '',
        secret: '',
        identity_secret:""
    },
    shop: {
        steamid: '',
        username: '',
        password: '',
        secret: '',
        identity_secret: '',
        timeForCancelOffer: 300
    },
    apiKey: '',
    nameSite: '',
    domain: '',
    secretKey: '517KccLYMb3a4P3F',
    admins: [
        '' , ''
    ]
}

module.exports = config;