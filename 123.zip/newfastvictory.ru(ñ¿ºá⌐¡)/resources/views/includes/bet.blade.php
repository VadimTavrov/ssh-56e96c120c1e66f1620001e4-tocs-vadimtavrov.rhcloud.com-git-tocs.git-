<div class="short">
    <div class="top">
        <div class="left">
            <img src="{{ $bet->user->avatar }}" alt="" title="">
            <div class="user"><span>{{ $bet->user->username }}</span> внес {{ $bet->itemsCount }} {{ trans_choice('lang.items', $bet->itemsCount) }}</div>
            <div class="numbs">
                <div>{{ $bet->price }} руб.</div>
                <div>{{ \App\Http\Controllers\GameController::_getUserChanceOfGame($bet->user, $bet->game) }}%</div>
            </div>
        </div>
        <div class="right">Билеты от <span>#{{ round($bet->from) }}</span> до <span>#{{ round($bet->to) }}</span></div>
    </div>
    <div class="items">
        @foreach(json_decode($bet->items) as $item)
            <div class="block">
                @if(!isset($item->img))
                    <img src="https://steamcommunity-a.akamaihd.net/economy/image/class/{{ \App\Http\Controllers\GameController::APPID }}/{{ $item->classid }}/52fx53f" alt=""/>
                @else
                    <img src="{{ asset($item->img) }}" alt=""/>
                @endif
                <div class="price">{{ $item->price }} руб.</div>
            </div>
        @endforeach
    </div>
</div>
