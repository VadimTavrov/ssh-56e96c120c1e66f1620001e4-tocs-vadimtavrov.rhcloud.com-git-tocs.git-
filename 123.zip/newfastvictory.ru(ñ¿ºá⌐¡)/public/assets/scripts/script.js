$(document).ready(function () {

    update_chat();
    FASTVICTORY.init();

    /* divs */
    game_container = $('.added');
    game_bank_div = $('.bank');
    bar_items_text = $('.progress .text');
    bar_width = $('.progress .line');
    user_chance = $('.user-chance');
    user_items = $('.user-items')
    game_timer = $('.game-timer');
    chances = $('.part');
    end_game_timer = $('.timer .time');
    roulette = $('.roulette');
    roulette_players = $('.roulette .roulette-player');
    round_number = $('.number')
    end_game_round = $('.end');
    chat = $('.scroll');
    error_message = $('.notification .error');
    success_message = $('.notification .success');
    error_message_text = $('.notification .error .message-error');
    success_message_text = $('.notification .success .message-success');
    success_message_header = $('.notification .success .message-header');
    error_message_header = $('.notification .error .message-header');
    current_game = $('.current-game');
    game_hash = $('.game_hash');
    end_game_info = $('.winner-timer');

    /* LAST-WINNER */
    last_winner_avatar = $('.last-winner .avatar');
    last_winner_name = $('.last-winner .name');
    last_winner_jackpot = $('.last-winner .jackpot');
    last_winner_chance = $('.last-winner .chance');
    /* LAST-WINNER END */

    // Statistic
    online_div = $('.stat .online');
    /* divs*/

    if (START) {
        var socket = io.connect(':2020');

        if (checkUrl()) {
        socket
            .on('connect', function () {
                console.log('Соединение установлено');
            })
            .on('disconnect', function () {
                console.log('Не удалось установить соединение !');
            })
            .on('online', function (data) {
                $(online_div).text(Math.abs(data));
            })
            .on('newDeposit', function (data) {
                data = JSON.parse(data);
                $(game_container).prepend(data.html);
                $(game_bank_div).html(Math.round(data.gamePrice) + ' руб.');
                $('title').text(Math.round(data.gamePrice) + ' руб - FASTVICTORY');
                $(bar_items_text).html(data.itemsCount + ' из 100 предметов');
                $(bar_width).css('width', data.itemsCount + '%');

                console.log(data.chances);
                html_chances = '';

                data.chances = sortByChance(data.chances);
                data.chances.forEach(function (info) {
                    if (USER_ID == info.steamid64) {
                        $('#myItemsCount').html(info.items + '<span style="font-size: 12px;">' + n2w(info.items, [' предмет', ' предмета', ' предметов']) + '</span>');
                        $(user_chance).text(info.chance + '%');
                    }
                    $('.id-' + info.steamid64).text(info.chance + '%');
                    html_chances += '<div><div class="chance">' + info.chance + '%</div><img src="' + info.avatar  + '" alt=""></div>';
                });

                $(chances).html(html_chances);
                $(chances).show();

                FASTVICTORY.init();
            })
            .on('forceClose', function () {
                $('.forceClose').removeClass('msgs-not-visible');
            })
            .on('timer', function (time) {
                $minute = lpad(Math.floor(time / 60), 1);
                $seconds = lpad(time - Math.floor(time / 60) * 60, 2);

                $(game_timer).text($minute + n2w($minute, [' минута и ', ' минуты и ', ' минут и ']) + $seconds + n2w($seconds, [' секунда', ' секунды', ' секунд']));
            })
            .on('slider', function (data) {

                // Таймер
                $(end_game_timer).text(lpad(data.time - Math.floor(data.time / 60) * 60, 2));

                if (ngtimerStatus) {
                    ngtimerStatus = false;
                    var users = data.users;

                    users = mulAndShuffle(users, Math.ceil(110 / users.length));
                    users[100] = data.winner;
                    html = '';
                    users.forEach(function (i) {
                        html += '<img src="' + i.avatar + '" alt="" title="">';
                    });
                    $(roulette_players).html(html);

                    $(roulette).slideDown();

                    $(round_number).text(data.round_number);

                    $(end_game_round).slideDown();

                    $(roulette_players).css('margin-left', -41);
                    if (data.showSlider) {
                        $(roulette_players).animate(
                            {marginLeft: -5704}, 1000 * 10,
                            function () {
                                fillWinnerInfo(data);
                                $(end_game_info).slideDown();
                            });
                    }

                    function fillWinnerInfo(data) {
                        data = data || {winner: {}};

                        var obj = {
                            totalPrice: data.game.price || 0,
                            number: data.game.price ? ('#' + Math.floor(data.round_number * data.game.price)) : '???',
                            tickets: data.tickets || 0,
                            winner: {
                                image: data.winner.avatar || '???',
                                login: data.winner.username || '???',
                                id: data.winner.steamid64 || '#',
                                chance: data.chance || 0,
                                winTicket: data.ticket || '???'
                            }
                        };
                        $('.winner-chance').text(obj.winner.chance);
                        $('.count-tickets').text(obj.tickets);
                        $('.winner-ticket').text('#' + obj.winner.winTicket);
                        $('.winner img').attr('src', obj.winner.image);
                        $('.winner-name').text(obj.winner.login);
                        $('.winner-bank').text(obj.totalPrice + ' руб.');
                    }
                }
            })
            .on('newGame', function (data) {
                $(roulette).slideUp();
                $(end_game_info).slideUp();
                $(end_game_round).slideUp();
                $(game_container).html('');
                $(chances).html('');
                $(chances).hide();
                $(game_bank_div).html('0 руб.');
                $(bar_items_text).text('0 из 100 предметов');
                $(current_game).text('#' + data.id);
                $(bar_width ).css('width', '0%');
                $(game_hash).text(data.hash);
                $(user_items).html('0');
                $(user_chance).html('0%');
                $(game_timer).text('2 минуты и 00 секунд');
                $(end_game_timer).html('');
                $(roulette_players).html('');
                $('title').text('0 руб - FASTVICTORY');
                ngtimerStatus = true;
            })
            .on('lastwinner', function (data) {
                $(last_winner_avatar).html('<img src="' + data.avatar + '" alt="" title="" />');
                $(last_winner_name).html(data.username);
                $(last_winner_jackpot).html('Выигрыш: ' + data.price + ' руб.');
                $(last_winner_chance).html('Шанс: ' + data.percent + '%');
            })
            .on('queue', function (data) {
                console.log(data);
                if (data) {
                    var n = data.indexOf(USER_ID);
                    if (n !== -1) {
                        clearTimeout(declineTimeout);
                        declineTimeout = setTimeout(function () {
                            $(success_message).slideUp();
                        }, 1000 * 10)
                        $(success_message_text).text('Вы ' + (n + 1) + ' в очереди.');
                        $(success_message).slideDown();
                    }
                }
            })
            .on('chat_messages', function (data) {
                message = data;
                if (message && message.length > 0) {
                    $(chat).html('');
                    message = message.reverse();
                    for (var i in message) {

                        if (message[i].admin != 1) {
                            var html = '<div class="short" data-uuid="' + message[i].id + '" data-user="' + message[i].userid + '">';
                            html += '<div class="top">';
                            html += '<div class="avatar"><img src="https://steamcdn-a.akamaihd.net/steamcommunity/public/images/avatars/' + message[i].avatar + '"></div>';
                            html += '<div class="name">' + message[i].username + '</div>';
                            html += '<div class="date">' + message[i].time + '</div>';
                            html += '</div><div class="message">' + message[i].messages + '</div></div>';
                        }
                        else {
                            var html = '<div class="short" data-uuid="' + message[i].id + '">';
                            html += '<div class="top">';
                            html += '<div class="avatar"><img src="/assets/images/admin.png"></div>';
                            html += '<div class="name" style="color:red">Администратор</div>';
                            html += '<div class="date">' + message[i].time + '</div>';
                            html += '</div><div class="message">' + message[i].messages + '</div></div>';
                        }
                        $(chat).append(html);
                    }

                }
            })
            .on('depositDecline', function (data) {
                data = JSON.parse(data);
                if (data.user == USER_ID) {
                    clearTimeout(declineTimeout);
                    declineTimeout = setTimeout(function () {
                        $(error_message).slideUp();
                    }, 1000 * 10)
                    $(error_message_header).html('Ваше предложение обмена отклонено');
                    $(error_message_text).text(data.msg);
                    $(error_message).slideDown();
                }
            })}
            else {
                socket
                    .on('online', function (data) {
                        $(online_div).text(Math.abs(data));
                    })
            }
        var declineTimeout,
            timerStatus = true,
            ngtimerStatus = true;

    }

    /* HELPER FUNCTIONS */

    function lpad(str, length) {
        while (str.toString().length < length)
            str = '0' + str;
        return str;
    }

    function sortByChance(arrayPtr) {
        var temp = [],
            item = 0;
        for (var counter = 0; counter < arrayPtr.length; counter++) {
            temp = arrayPtr[counter];
            item = counter - 1;
            while (item >= 0 && arrayPtr[item].chance < temp.chance) {
                arrayPtr[item + 1] = arrayPtr[item];
                arrayPtr[item] = temp;
                item--;
            }
        }
        return arrayPtr;
    }


    function n2w(n, w) {
        n %= 100;
        if (n > 19) n %= 10;

        switch (n) {
            case 1:
                return w[0];
            case 2:
            case 3:
            case 4:
                return w[1];
            default:
                return w[2];
        }
    }


    function mulAndShuffle(arr, k) {
        var
            res = [],
            len = arr.length,
            total = k * len,
            rand, prev;
        while (total) {
            rand = arr[Math.floor(Math.random() * len)];
            if (len == 1) {
                res.push(prev = rand);
                total--;
            }
            else if (rand !== prev) {
                res.push(prev = rand);
                total--;
            }
        }
        return res;
    }

    function checkUrl() {
        var pathname = window.location.pathname;

        if (pathname.indexOf('history') + 1) {
            return false;
        }
        else {
            return true;
        }
    }

    /* DESIGN SCRIPT ELEMENTS */

    $('.profile > .avatar').click(function (e) {
        $(this).toggleClass('active');
        $('.profile > .sub').toggle(0);
        e.stopPropagation();
    });

    $('.profile').click(function (e) {
        e.stopPropagation();
    });

    $('html').click(function () {
        var link = $('.profile > .avatar');
        if (link.hasClass('active')) {
            link.click();
        }
    });

    $('.chat-header').click(function () {
        if ($('.chat-container').height() < 452) {
            chat_height = 452;
        } else {
            chat_height = 0;
        }
        $('.chat-container').animate({
            height: chat_height + 'px'
        }, 100);
    });

    $('.add-cards').click(function () {
        $('#cards-modal').arcticmodal();
    });

    $('.fair').click(function () {
        $('#fairplay-modal').arcticmodal();
    });

    $(function() {
        $('.north').tipsy({gravity: 'n'});
        $('.south').tipsy({gravity: 's'});
        $('.east').tipsy({gravity: 'e'});
        $('.west').tipsy({gravity: 'w'});
    });


    /* CHAT SCRIPT START */

    $(function () {

        $('#chatInput').keypress(function (e) {
            if (!e.shiftKey && e.which == 13) {
                sendMessage($(this).val());
                $(this).val('');
                e.preventDefault();
            }
        });

        $('.chat-submit-btn').click(function (e) {
            sendMessage($('#chatInput').val());
            e.preventDefault();
        });

    });

    function sendMessage(text) {
        $.post('/add_message', {messages: text}, function (message) {
            if (message && message.status) {
                $.notify(message.message, message.status);
                $('#chatInput').val('');
            }
        });
    }


    function update_chat() {
        $.ajax({
            type: "GET",
            url: "/chat",
            dataType: "json",
            cache: false,
            success: function (message) {

                if (message && message.length > 0) {
                    if (message && message.length > 0) {
                        $(chat).html('');
                        message = message.reverse();
                        for (var i in message) {

                            if (message[i].admin != 1) {
                                var html = '<div class="short" data-uuid="' + message[i].id + '" data-user="' + message[i].userid + '">';
                                html += '<div class="top">';
                                html += '<div class="avatar"><img src="https://steamcdn-a.akamaihd.net/steamcommunity/public/images/avatars/' + message[i].avatar + '"></div>';
                                html += '<div class="name">' + message[i].username + '</div>';
                                html += '<div class="date">' + message[i].time + '</div>';
                                html += '</div><div class="message">' + message[i].messages + '</div></div>';
                            }
                            else {
                                var html = '<div class="short" data-uuid="' + message[i].id + '">';
                                html += '<div class="top">';
                                html += '<div class="avatar"><img src="/assets/images/admin.png"></div>';
                                html += '<div class="name" style="color:red">Администратор</div>';
                                html += '<div class="date">' + message[i].time + '</div>';
                                html += '</div><div class="message">' + message[i].messages + '</div></div>';
                            }
                            $(chat).append(html);
                        }
                    }
                }
            }
        });
    }

    /* CHAT SCRIPT END */


    /* TRADE URL SAVE */

    $('.trade-url')
    .keypress(function (e) {
        if (e.which == 13) $(this).next().click()
    })
        .on('paste', function () {
            var that = $(this);
            setTimeout(function () {
                that.next().click();
            }, 0);
        });

    $('.save-trade-url').click(function () {
        var that = $(this).prev();
        $.ajax({
            url: '/settings/save',
            type: 'POST',
            dataType: 'json',
            data: {trade_link: $(this).prev().val()},
            success: function (data) {
                clearTimeout(declineTimeout);
                declineTimeout = setTimeout(function () {
                    $(error_message).slideUp();
                    $(success_message).slideUp();
                }, 1000 * 10)

                if (data.status == 'success') {
                    $(success_message_header).html('');
                    $(success_message).slideDown();
                    $(success_message_text).text(data.msg);
                }
                else {
                    $(error_message_header).html('');
                    $(error_message).slideDown();
                    $(error_message_text).text(data.msg);
                }

            },
            error: function () {
                console.log('Ошибка сохранения ссылки')
            }
        });
        return false;
    });

    /* TRADE URL SAVE END */

});