<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">

    <meta property="og:image" content="{{ asset('assets/images/rulet.png') }}">
    <meta name="og:title" content="FASTVICTORY.RU : Win CS:GO Skins"/>
    <meta name="og:description"
          content="A website where Players deposit skins, once a pre-defined threshold is reached a depositer will be choosen, with odds based on the values of it's deposited skin, and awarded with ALL the skins in the pool."/>

    <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width">

    <title>{{ $title }}FASTVICTORY.RU</title>
    <link rel="icon" type="image/png" href="{{ asset('favicon.png') }}"/>
    <link rel="stylesheet" href="{{ asset('assets/styles.css') }}"/>
    <link rel="stylesheet" href="{{ asset('assets/styles/fonts.css') }}"/>
    <link rel="stylesheet" href="{{ asset('assets/styles/arcticmodal.css') }}"/>
    <meta name="csrf-token" content="{!!  csrf_token()   !!}">
    <script src="{{ asset('assets/scripts/jquery-1.7.2.js') }}"></script>
    <script src="{{ asset('assets/scripts/arcticmodal.min.js') }}"></script>
    <script src="{{ asset('assets/scripts/script.js') }}"></script>
    <script src="{{ asset('assets/scripts/jquery-tipsy.js') }}"></script>
    <script src="{{ asset('assets/scripts/main.js') }}"></script>
    <script src="{{ asset('assets/scripts/shop/lodash.min.js') }}"></script>
    <script src="{{ asset('assets/scripts/shop/underscore-min.js') }}"></script>


    <script src="http://cdn.socket.io/socket.io-1.4.0.js"></script>

    <script>
        @if(!Auth::guest())
              var avatar = '{{ $u->avatar }}';
              const USER_ID = '{{ $u->steamid64 }}';
        @else
              const USER_ID = 'null';
        @endif
              var START = true;
    </script>
</head>

<body>

<div class="user-panel">

    @if(!Auth::guest())
        <div class="profile">
            <div class="avatar"><img src="{{ $u->avatar }}" alt="" title=""/></div>
            <div class="sub">
                <div class="top">
                    <div class="left">Добрый день, <span>{{ $u->username }}</span></div>
                    <div class="right">У вас {{ $u->votes }} уровень</div>
                </div>
                <ul>
                    <li>Победы - {{ json_decode(\App\User::userInfo($u->id))->wins }}</li>
                    <li>Поражения - {{ json_decode(\App\User::userInfo($u->id))->loss }}</li>
                    <li>Коэффициент - {{ json_decode(\App\User::userInfo($u->id))->winrate }}%</li>
                </ul>
                <div class="settings">
                    <div>Обязательно укажите ссылку на обмен</div>
                    <div class="clear"></div>
                    <input type="text" class="trade-url" name="" placeholder="http://steampowered.com/tradeoffers/demos"
                           value="{{ $u->trade_link }}">
                    <input type="submit" class="save-trade-url" name="" value="">
                </div>
                <div class="logout">
                    <a href="{{ route('logout') }}">Выйти</a>
                </div>
            </div>
        </div>
    @else
        <a href="{{ route('login') }}" class="login"></a>
    @endif

    <ul>
        <li><a href="{{ route('top') }}" class="west" original-title="Топ игроков"></a></li>
        <li><a href="{{ route('history') }}" class="west" original-title="История"></a></li>
        <li><a href="{{ route('about') }}" class="west" original-title="О сайте"></a></li>
        <li><a href="http://vk.com/fastvictoryru" class="west" original-title="Вконтакте"></a></li>
        <li><a href="{{ route('cards') }}" class="west" original-title="Магазин"></a></li>
    </ul>
</div>

<div class="container">

    <header>

        <div class="top">

            <a href="{{ route('index') }}" class="logotype"></a>

            <div class="stat">
                <div class="block">
                    <div class="online">0</div>
                    человек онлайн
                </div>
                <div class="block">
                    <div>{{ \App\Game::gamesToday() }}</div>
                    игр сегодня
                </div>
                <div class="block">
                    <div>{{ \App\Game::maxPrice() }}</div>
                    макс. выигрыш
                </div>
            </div>

        </div>

        <div class="bottom">

            <div class="inform">
                <div class="block">Чем больше сумма всех поставленных Вами предметов, тем выше Ваш шанс на победу.</div>
                <div class="block">Максимальный депозит - {{ \App\Http\Controllers\GameController::MAX_ITEMS }} предметов. Минимальная сумма депозита - {{ \App\Http\Controllers\GameController::MIN_PRICE }} руб.</div>
                <div class="block">Добавь к своему нику в Steam FASTVICTORY.RU и получи бонус к выигрышу +10%.</div>
            </div>

            <div class="last-winner">
                <div class="title">Последний победитель</div>
                <div class="avatar"><img src="{{ json_decode(\App\Game::last_winner())->avatar }}" alt="" title=""/></div>
                <ul>
                    <li class="name">{{ json_decode(\App\Game::last_winner())->username }}</li>
                    <li class="jackpot">Выигрыш: {{ json_decode(\App\Game::last_winner())->bank }} руб.</li>
                    <li class="chance">Шанс: {{ json_decode(\App\Game::last_winner())->chance }}%</li>
                </ul>
            </div>

            <div class="giveaway">
                <div class="time">Открытие магазина</div>
                <div>Продажа вещей на 25% меньше чем в Steam</div>
                <img src="{{ asset('item-1.png') }}" alt="" title=""/>
                <a href="{{ route('cards') }}">ПЕРЕЙТИ В МАГАЗИН</a>
            </div>

        </div>

    </header>

    @yield('content')


</div>

<script>
    @if(!Auth::guest())
    function updateBalance() {
        $.post('{{route('get.balance')}}', function (data) {
            $('.userBalance').text(data + ' руб.');
        });
    }
    function addTicket(id, btn) {
        $.post('{{route('add.ticket')}}', {id: id}, function (data) {
            updateBalance();
            return $.notify(data.text, data.type);
        });
    }
    @endif
</script>
</body>
</html>
