$(function () {

    FASTVICTORY.init();

    window.realList = [];
    window.realListObj = {};
    window.ITEM = {};

    window.itemsHolder = $('.store');
    window.allItems;

    var item_tpl = _.template($('#item-template').html());

    $.ajax({
        url: 'shop',
        type: 'POST',
        dataType: 'json',
        success: function (data) {

            if (data.off) {
                $('#loading-msg').hide();
                $('#off-msg').show();
                return;
            }

            if (!data.list.length) {
                $('#loading-msg').hide();
                $('#empty-msg').show();
                return;
            }

            data.list.forEach(function (zipItem) {
                var i = 0;
                zipItem = {
                    id: zipItem[i++],
                    count: zipItem[i++],
                    name: zipItem[i++],
                    priceCent: zipItem[i++],
                    classid: zipItem[i++],
                    exterior: zipItem[i++],
                    rarity: zipItem[i++],
                    rarity_text: zipItem[i++],
                };

                var priceText = Math.round(zipItem.priceCent);

                if(zipItem.name.length > 35) {
                    zipItem.name = zipItem.name.substr(0, 34) + '...'
                }

                if(zipItem.exterior !== null) {
                    if (zipItem.exterior.length > 19) {
                        zipItem.exterior = zipItem.exterior.substr(0, 16) + '...'
                    }
                }

                var obj = {
                    id: zipItem.id,
                    name: zipItem.name,
                    steamPrice: zipItem.priceCent,
                    sortPrice: zipItem.priceCent,
                    priceText: priceText,
                    classid: zipItem.classid,
                    count: zipItem.count,

                    filter_exterior: zipItem.exterior,
                    filter_rarity: zipItem.rarity,
                    filter_rarity_text: zipItem.rarity_text,

                    type2: zipItem.exterior,
                    className: zipItem.name.indexOf("в…") == -1 ? [zipItem.rarity][0] : 'rare'
                };

                realList.push(obj);
                realListObj[zipItem.id] = obj;
            });

            $('#items-total').text(_.reduce(realList, function (memo, num) {
                return memo + num.count;
            }, 0));

            itemsHolder.hide();

            realList.sort(function (a, b) {
                return b.sortPrice - a.sortPrice
            });

            realList.forEach(function (item) {
                item.image = 'https://steamcommunity-a.akamaihd.net/economy/image/class/730/' + item.classid + '/100fx100f';
                item.el = $(item_tpl(item));
                itemsHolder.append(item.el);
            });

            $('#loading-msg').hide();
            itemsHolder.show();

            allItems = itemsHolder.children('.short');

        },
        error: function () {
            itemsHolder.html('<div style="text-align: center">Произошла ошибка. Попробуйте еще раз</div>');
        }
    });

    $('#searchInput, #priceFrom, #priceTo').keyup(filterFn);

    $(document.body).on('click', '.deposit-item', function (e) {
        e.preventDefault();

        ITEM = realListObj[$(this).data('id')];

        $('#buyModal img').attr('src', ITEM.image);
        $('#buyModal .name').text(ITEM.name);
        $('#buyModal .rarity').text(ITEM.filter_rarity_text);

        if(ITEM.filter_exterior != null) {
            $('#buyModal .type2').text(ITEM.filter_exterior);
        }

        $('#buyModal .steamPrice').html(ITEM.priceText);
        $('#buyModal .ourPrice').html(ITEM.priceText);

        $('.shop-buy-btn').show();
        $('.buy-status').hide();

        $('#buyModal').arcticmodal();

        $('.explore-game').hide();

        $.ajax({
            url: 'shop',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'link',
                id: ITEM.id
            },
            success: function (data) {
                $('.explore-game').attr('href', data.link);
                $('.explore-game').show();
            }
        });
    });

    $(document.body).on('click', '.shop-buy-btn', function (e) {
        $.ajax({
            url: '/shop/buy',
            type: 'POST',
            dataType: 'json',
            data: {id: ITEM.id},
            success: function (data) {
                if (data.success) {
                    $('.shop-buy-btn').hide();
                    if (--ITEM.count == 0) {
                        ITEM.el.remove()
                    }
                    else {
                        ITEM.el.find('.deposit-count').text('x' + ITEM.count);
                    }
                    text = data.msg;
                }
                else {
                    text = data.msg;
                }
                $('.buy-status').html(text);
                $('.buy-status').show();
            },
            error: function () {
                $('.buy-status').text('<div style="text-align: center">Произошла ошибка. Попробуйте еще раз</div>');
                $('.buy-status').show();
            }
        });
    });
});

var filterFn = _.debounce(filterAndSort, 200);
function filterAndSort() {
    var args = [];

    ['exterior_all', 'rarity_all', 'type_all'].forEach(function(sel) {
        var exterior = $('#' + sel).val();
        if (exterior) {
            var arr = [];
            _.each(exterior, function(tag) {
                arr.push(window['filter_' + sel][tag]);
            });
            args.push(_.union.apply(null, arr));
        }
    });

    var from = parseFloat($('#priceFrom').val()) || 0;
    var to = parseFloat($('#priceTo').val()) || 10e10;

    if (to < from) to = 10e10;

    var p = _.filter(realList, function (item) {
        var _price = Math.round(item.sortPrice);
        return _price >= from && _price <= to;
    });

    p = _.pluck(p, 'id');
    args.push(p);


    var text = $('#searchInput').val().trim();
    text = text.replace('|', '\\|');
    var p = _.filter(realList, function (item) {
        return (new RegExp(text, 'i').test(item.name));
    });
    p = _.pluck(p, 'id');
    args.push(p);

    if (!args.length) return allItems.removeClass('hidden');

    var s = _.intersection.apply(null, args);

    var count = 0;
    allItems.addClass('hidden');
    s.forEach(function (id) {
        realListObj[id].el.removeClass('hidden');
        count += realListObj[id].count;
    });
    $('#filter-total').text(count);

    console.log(realList);
}