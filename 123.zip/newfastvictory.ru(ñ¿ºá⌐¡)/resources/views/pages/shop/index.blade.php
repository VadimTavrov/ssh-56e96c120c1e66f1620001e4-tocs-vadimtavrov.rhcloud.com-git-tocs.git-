@extends('layout')

@section('content')
    <script src="{{ asset('assets/scripts/shop.js') }}"></script>

    @if(!Auth::guest())
        <div class="store-sort">

            <div class="left">
                <div class="top">
                    <div class="text">Все предметы (<div id="filter-total" style="display: inline-block">{{ \App\Shop::countItems() }}</div>)</div>
                </div>
            </div>
            <div class="bal-info">
                <div class="balance">На вашем балансе {{ $u->money }} руб.</div>
                <div class="clear"></div>
                <form method="GET" action="/pay">
                    <input type="hidden" name="user_id" value="{{ $u->id }}">
                    <input type="text" name="sum" placeholder="Введите сумму">
                    <input type="submit" name="" value="Пополнить">
                </form>
            </div>

        </div>

        <div class="content">
            <!-- <middle> -->

            <div class="store">
                <script type="text/template" id="item-template">
                    <div class="short <%= className %> up-<%= className %>">
                        <img src="<%= image %>" alt="" title=""/>
                        <ul>
                            <li><%= name %></li>
                            <li><%= filter_rarity_text %><%= type2 ? ', ('+type2+')' : ''%></li>
                            <li>Стоимость: <%= priceText %> руб. <% if (count > 1) { %> (x<%= count %>) <% } %></li>
                        </ul>
                        <a href="#buy" class="deposit-item" data-id="<%= id %>"></a>
                    </div>
                </script>
            </div>


            <div style="display: none;">
                <div class="box-modal-2" id="buyModal">
                    <img src="item-3.png" alt="" title=""/>
                    <ul>
                        <li class="name"></li>
                        <li><div class="rarity" style="display: inline-block"></div>, <div class="type2" style="display: inline-block"></div></li>
                    </ul>
                    <div class="bottom">
                        <div class="left">Стоимость: <div class="steamPrice" style="display: inline-block"></div> руб. (-25%)</div>
                        <a href="#" class="shop-buy-btn">Подтвердить покупку</a>
                    </div>
                </div>
            </div>

        @else
        <div class="buy-cards-container">
            <div class="buy-cards-block">
                <div class="deposit-txt-info">Вам нужно авторизоваться</div>
            </div>
        </div>
    @endif
@endsection
