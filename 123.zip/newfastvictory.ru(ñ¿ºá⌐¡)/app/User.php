<?php

namespace App;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;

class User extends Model implements AuthenticatableContract, CanResetPasswordContract
{
    use Authenticatable, CanResetPassword;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'users';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['username', 'avatar', 'steamid', 'steamid64', 'inventory', 'ip'];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['trade_link', 'remember_token', 'is_admin', 'is_moderator', 'accessToken'];

    public function games()
    {
        return $this->hasMany('App\Game');
    }

    public function bets()
    {
        return $this->hasMany('App\Bet');
    }

    public function betsByGame($gameid)
    {
        return \DB::table('bets')->where('user_id', $this->id)->where('game_id', $gameid)->orderBy('created_at', 'desc')->get();
    }

    public function lastBet()
    {
        return $this->hasOne('App\Bet')->latest();
    }

    public function itemsCountByGame($game)
    {
        return $this->bets()->where('game_id', $game->id)->sum('itemsCount');
    }

    public static function userInfo($id)
    {
        $games = Game::where('winner_id', $id)->get();
        $wins = $games->count();

        $gamesPlayed = \DB::table('games')
            ->join('bets', 'games.id', '=', 'bets.game_id')
            ->where('bets.user_id', $id)
            ->groupBy('bets.game_id')
            ->orderBy('games.created_at', 'desc')
            ->select('games.*', \DB::raw('SUM(bets.price) as betValue'))->get();

        $loss = count($gamesPlayed) - $wins;

        $winrate = count($gamesPlayed) ? round($wins / count($gamesPlayed), 3) * 100 : 0;

        $userinfo = [
            'wins' => $wins,
            'loss' => $loss,
            'winrate' => $winrate,
        ];

        return json_encode($userinfo);
    }
}
