<?php

Route::group(['middleware' => 'auth'], function () {

get('/admin', ['as' => 'give', 'uses' => 'AdminController@admin']);	
get('/mute', ['as' => 'give', 'uses' => 'AdminController@mute']);	
post('/mute', ['as' => 'give', 'uses' => 'AdminController@mute']);	
get('/clearsupport', ['as' => 'give', 'uses' => 'AdminController@clearsupport']);	
get('/supportban', ['as' => 'give', 'uses' => 'AdminController@supportban']);	
get('/setadmin', ['as' => 'give', 'uses' => 'AdminController@setadmin']);	
get('/sendmoney', ['as' => 'give', 'uses' => 'AdminController@sendmoney']);
get('/removemoney', ['as' => 'give', 'uses' => 'AdminController@removemoney']);
});
