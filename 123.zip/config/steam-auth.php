<?php

return [

    /*
     * Redirect url after login
     */
    'redirect_url' => '/login',

    'api_key' => 'C93D4197114ED13D870DAD8A5F08201A'

];