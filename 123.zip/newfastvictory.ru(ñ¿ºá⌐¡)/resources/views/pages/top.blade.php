@extends('layout')

@section('content')
    <div class="title-page"><span>Топ победителей</span></div>

    <div class="content">
        <!-- <middle> -->

        <div class="table">

            <div class="list">
                <div class="tb1">Место</div>
                <div class="tb2">Аватар</div>
                <div class="tb3">Ник в Steam</div>
                <div class="tb4">Всего игр</div>
                <div class="tb5">Победы</div>
                <div class="tb5">Выиграл</div>
            </div>

            @foreach($users as $user)
                <div class="list">
                    <div class="tb1">{{ $place++ }}</div>
                    <div class="tb2"><img src="{{ $user->avatar }}" alt="" title=""/></div>
                    <div class="tb3">{{ $user->username }}</div>
                    <div class="tb4">{{ $user->games_played }}</div>
                    <div class="tb5">{{ $user->wins_count }}</div>
                    <div class="tb5">{{ round($user->top_value) }} руб.</div>
                </div>
            @endforeach

        </div>

        <!-- </middle> -->
    </div>
@endsection