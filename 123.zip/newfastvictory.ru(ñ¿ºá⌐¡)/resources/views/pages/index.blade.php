@extends('layout')

@section('content')
    <div class="title-page">
        <div>Текущая игра <span class="current-game">#{{ $game->id }}</span></div>
        <div>В банке <span class="bank">{{ round($game->price) }} руб.</span></div>
    </div>

    <div class="content">
        <!-- <middle> -->

        <div class="top-game">
            <div class="progress">
                <div class="text">{{ $game->items }} из 100 предметов</div>
                <div class="line" style="width: {{ $game->items }}%;"></div>
            </div>
            <div class="timer">
                <div>До игры осталось</div>
                <div></div>
                <div class="game-timer">2 минуты и 00 секунд</div>
            </div>
        </div>

        <div class="roulette" style="display: none;">
            <div class="roulette-player"></div>
        </div>

        <div class="winner-timer" style="display: none;">
            <ul class="winner">
                <li>Победный билет: <span class="winner-ticket">#</span> (Всего: <div class="count-tickets" style="display: inline-block"></div>) <a href="#" class="check"></a></li>
                <li>Победил игрок:<img src="" alt="" title=""><a href="#" class="winner-name"></a> (<div class="winner-chance" style="display: inline-block"></div>%)</li>
                <li>Выигрыш: <span class="winner-bank"></span></li>
            </ul>
            <div class="timer"><div class="time"></div>до начала</div>
            <div class="clear"></div>
        </div>

        <div class="end" style="display: none;">
            <ul>
                <li>ИГРА ЗАВЕРШИЛАСЬ</li>
                <div class="round-end">Число раунда: <span class="number"></span></div>
            </ul>
        </div>

        @if(!Auth::guest())
        <div class="panel">
            <ul>
                <li>Вы внесли <span class="user-items" style="color: #FFFFFF;">{{ $user_items }}</span> из 100 предметов</li>
                <li>Мин. сумма депозита {{ \App\Http\Controllers\GameController::MIN_PRICE }} руб. Макс. депозит {{ \App\Http\Controllers\GameController::MAX_ITEMS }} предметов.</li>
            </ul>
            <div class="right">
                <div>Ваш шанс на победу <span class="user-chance">{{ $user_chance }}%</span></div>
                <a href="#" class="add-cards">Внести карточки</a>
                <a href="@if(!empty($u->accessToken)) {{ route('deposit') }} @endif" target="_blank" class="@if(empty($u->accessToken))  @endif">Внести предметы</a>
            </div>
        </div>

            <div class="notification">
                <div class="success" style="display: none;">
                    <div class="message-header">Ваш депозит обрабатывается!</div>
                    <div class="message-success"></div>
                </div>
                <div class="error" style="display: none;">
                    <div class="message-header">Ваше предложение обмена отклонено!</div>
                    <div class="message-error"></div>
                </div>
            </div>
        @endif

        <div class="part" @if($game->items == 0) style="display: none;" @endif>
           @foreach($chances as $info)
                <div><div class="chance">{{ $info->chance }}%</div><img src="{{ $info->avatar }}" alt="" title=""></div>
           @endforeach
        </div>


        <div class="added">

            @foreach($bets as $bet)
                @include('includes.bet')
            @endforeach

        </div>

            <div class="start">
                <ul>
                    <li>ИГРА НАЧАЛАСЬ ВНОСИТЕ ДЕПОЗИТЫ!</li>
                    <li>Хэш раунда: <span class="game_hash">{{ md5($game->rand_number) }}</span></li>
                </ul>
                <a href="#" class="fair">Честная игра</a>
            </div>

        </div>

        <!-- </middle> -->
    </div>

    </div>

    <!-- CHAT START -->

    <div class="chat">
        <div class="chat-header">Окно общения</div>
        <div class="chat-container" style="height: 0;">

            <div class="inbox">
                <div class="scroll">
                </div>
            </div>

            <div class="form">
                <textarea name="" id="chatInput" placeholder="Ваше сообщение..."></textarea>
                <input type="submit" class="chat-submit-btn" value="">
            </div>

        </div>
    </div>

    <!-- CHAT END -->

    @if(!Auth::guest())
    <!-- CARDS START -->
    <div style="display: none;">
        <div class="box-modal cardsw" id="cards-modal">
            <div class="title">Ваш баланс: <span class="userBalance">{{ $u->money }} руб.</span></div>

            <div class="balance">
                <div>Пополнить баланс</div>
                <form method="GET" action="/pay">
                    <input type="hidden" name="user_id" value="{{ $u->id }}">
                    <input type="text" name="sum" placeholder="Введите сумму">
                    <input type="submit" name="" value="Пополнить">
                </form>
            </div>

            <div class="cards">
                @foreach(\App\Ticket::all() as $ticket)
                    <div class="block sm{{ $ticket->id }}">
                        <div class="sum">{{ floor($ticket->price) }} руб.</div>
                    </div>
                @endforeach
            </div>

            <div class="links">
                @foreach(\App\Ticket::all() as $ticket)
                    @if($ticket->price > $u->money)
                        <a href="#">Пополнить</a>
                    @else
                        <a href="#" onclick="addTicket({{ $ticket->id }}, this)">Внести</a>
                    @endif
                @endforeach
            </div>
    </div>
    <!-- CARDS END -->
    @endif


   <!-- TICKETS START -->
    <div style="display: none;">
        <div class="box-modal fairplay" id="fairplay-modal">
            <div class="title">Как мне убедиться, что вы не подтасовываете билеты?</div>
            <div class="text">В начале каждого раунда мы генерируем случайное число от <span>0</span> до <span>1</span>, например - <span>0.8654121452451</span>. Данное число меняет свое значение при каждой новой ставке, т.е заранее редугадать какой будет банк до цента не возможно, собственно узнать новое число раунда соответствено тоже не получится.</div>
            <div class="text">Далее, при внесении ставки в игру каждому игроку выдаются билеты (<span>1 билет = 0.01$</span>). В конце игры число раунда (<span>0.8654121452451</span>) умножается на количество билетов в игре (например сумма банка в <span>100 долларов</span> подразумевает под собой <span>10 000 билетов</span>), т.е. получаем <span>0.8654121452451 * 10 000 = 8654 билет</span>.</div>
            <div class="title">Проверка честной игры</div>
            <div class="form">
                <input type="text" name="" placeholder="Хэш раунда">
                <input type="text" name="" placeholder="Число раунда">
                <input type="text" name="" placeholder="Банк игры">
                <input type="submit" name="" value="Проверить игру">
                <div class="result">Победный билет: <span>Хеш раунда не совпадает</span>
                </div>
            </div>
        </div>
   <!-- TICKETS END -->

@endsection